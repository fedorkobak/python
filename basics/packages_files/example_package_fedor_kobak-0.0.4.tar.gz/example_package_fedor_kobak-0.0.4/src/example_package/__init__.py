print("I'm installed package!")
