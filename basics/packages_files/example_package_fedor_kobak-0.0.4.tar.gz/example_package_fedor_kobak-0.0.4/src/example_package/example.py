def do_something():
    print("doing something")
