# Example
This is a toy package I'm using to get used to deploying Python packages on PyPI.
